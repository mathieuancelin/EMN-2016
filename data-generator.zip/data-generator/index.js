var faker = require('faker');
var express = require('express');

var app = express();
app.use(express.static(__dirname + '/public'));

var tokenCache = {};
var timeCache = {};

function rnd(max) {
  return (Math.random() * max) + 1;
}

app.get('/data/:channel', function (req, res) {
  var channel = req.params.channel;
  var userId = req.get('X-User-Id');
  var authToken = req.get('X-Auth-Token');
  if (!userId) {
    res.status(490).send({ error: 'No X-User-Id header specified' });
  }
  if (!authToken) {
    res.status(491).send({ error: 'No X-Auth-Token header specified' });
  }
  var lastToken = tokenCache[userId];
  var lastTime = timeCache[userId];
  if (!lastToken) {
    res.status(492).send({ error: 'You don\'t have any Auth Token generated !!!' });
  } else {
    if (lastToken.count <= 0) {
      res.status(403).send({ error: 'Your Authentication token is expired !!!' });
    } else if (lastTime && lastTime > Date.now()) {
      res.status(429).send({ error: 'Too much request !!!' });
    } else if (lastToken && lastToken.value !== authToken) {
      res.status(493).send({ error: 'Bad X-Auth-Token value !!!' });
    } else {
      tokenCache[userId].count = tokenCache[userId].count - 1;
      timeCache[userId] = Date.now() + 4000; // TODO : random
      var nbr = rnd(100);
      var data = [];
      for (var i = 0; i < nbr; i++) {
        data.push({
          channel: channel,
          account: faker.finance.account(),
          accountName: faker.finance.accountName(),
          mask: faker.finance.mask(),
          amount: faker.finance.amount(),
          transactionType: faker.finance.transactionType(),
          currencyCode: faker.finance.currencyCode(),
          currencyName: faker.finance.currencyName(),
          currencySymbol: faker.finance.currencySymbol(),
          bitcoinAddress: faker.finance.bitcoinAddress(),
        });
      }
      res.send({ channel: channel, generatedAt: Date.now(), data: data });
    }
  }
});

app.get('/token/:id', function(req, res) {
  var id = req.params.id;
  if (tokenCache[id] && tokenCache[id].expireAt > Date.now()) {
    res.status(429).send({ error: 'Too much request !!!' });
  } else {
    var token = {
      id: faker.random.uuid(),
      value: faker.helpers.slugify(faker.random.words()),
      expireAt: Date.now() + 20000, // TODO : random
      count: 10, // TODO : random
    };
    tokenCache[id] = token;
    res.send(token);
  }
});

app.get('/__state', function(res, res) {
  res.send({
    timeCache: timeCache,
    tokenCache: tokenCache,
  });
});

app.delete('/__history/:id', function(req, res) {
  var id = req.params.id;
  delete timeCache[id];
  delete tokenCache[id];
  res.send({
    timeCache: timeCache,
    tokenCache: tokenCache,
  });
});

var port = (process.env.PORT || 3000);
app.listen(port, function () {
  console.log('Data Generator is ready on port ' + port + '!');
});
