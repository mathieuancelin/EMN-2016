# Data API

API root : `https://data-generator-emn.herokuapp.com/`

## Les tokens

URL : `https://data-generator-emn.herokuapp.com/token/:id`

Comportement:

* le parametre id est votre nomPrenom en camel case
* renvoi une erreur 429 si plus d'un appel en moins de 20 secondes

```javascript
 {
   "id": "e921c257-459d-4a02-b473-36b80972a915",
   "value": "Strategist-Ergonomic-Steel-Sausages-Cambridgeshire",
   "expireAt": 1461932865462,
   "count": 10
 }
 ```


## les datas

URL : `https://data-generator-emn.herokuapp.com/data/:channel`

Headers:

* X-User-Id: l'id avec lequel le token a été récupéré
* X-Auth-Token: le champ value du token récupéré

Comportement:

* le parametre channel est un mot clé
* renvoi une erreur 490 si le header X-User-Id n'est pas présent
* renvoi une erreur 491 si le header X-Auth-Token n'est pas présent
* renvoi une erreur 492 si vous tentez d'appeler le service sans avoir généré un token au préalable
* renvoi une erreur 403 si vous avez appelé le service plus de 10 fois avec le même token
* renvoi une erreur 429 si vous appelez le service plus d'une fois en 4 secondes
* renvoi une erreur 493 si la valeur du header X-Auth-Token est différente de celle du token généré

```javascript

{
    "channel": "nantes",
    "data": [
        {
            "account": "26398406",
            "accountName": "Investment Account",
            "amount": "407.00",
            "bitcoinAddress": "3ER4LKZGK9VAUJ46HT6I0LR94VZHJU",
            "channel": "nantes",
            "currencyCode": "MOP",
            "currencyName": "Bolivar Fuerte",
            "currencySymbol": "Php",
            "mask": "1772",
            "transactionType": "deposit"
        },
        {
            "account": "89175844",
            "accountName": "Home Loan Account",
            "amount": "311.00",
            "bitcoinAddress": "3VKTU8SG76HG0BQD8R9KK5HCHYU6YEZFZ4",
            "channel": "nantes",
            "currencyCode": "SHP",
            "currencyName": "Codes specifically reserved for testing purposes",
            "currencySymbol": "лв",
            "mask": "6965",
            "transactionType": "invoice"
        }
    ],
    "generatedAt": 1461933063167
}
```

## l'application

Créez une application qui va consommer en continu les données générées par `https://data-generator-emn.herokuapp.com/` et qui les restitueront sous forme de websocket.
Consommez ensuite votre propre service pour faire un [`column chart`](http://www.highcharts.com/demo/column-basic) [dynamique](http://www.highcharts.com/demo/dynamic-update) avec les valeurs tirées du service.

Un bon pattern pour la consommation du service est de créer une sorte de machine a état dans un acteur, et de notifier un autre acteur `maitre` lorsque des données sont disponibles.

* [https://www.playframework.com/documentation/2.5.x/ScalaWebSockets](https://www.playframework.com/documentation/2.5.x/ScalaWebSockets)
* [https://www.playframework.com/documentation/2.5.x/ScalaAkka](https://www.playframework.com/documentation/2.5.x/ScalaAkka)
