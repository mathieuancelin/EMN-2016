package controllers

import java.util.concurrent.TimeUnit
import javax.inject._

import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import akka.stream.Materializer
import play.api._
import play.api.libs.json.{JsArray, JsValue}
import play.api.libs.streams.ActorFlow
import play.api.libs.ws.WSClient
import play.api.mvc._
import services._

import scala.concurrent.duration.Duration

@Singleton
class HomeController @Inject()(ws: WSClient)(implicit actorSystem: ActorSystem, materializer: Materializer) extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def data(channels: String) = WebSocket.accept[JsValue, JsValue] { request =>
    val children = channels.split("::")
      .map(channel =>
        actorSystem.actorOf(DataClient.props("Mathieu", channel, ws))).toSeq
    ActorFlow.actorRef(out =>  DataWebsocketActor.props(out, children))
  }
}

case class StartChildren()
case class Drain()
case class StartDraining()

object DataWebsocketActor {
  def props(out: ActorRef, children: Seq[ActorRef]) = Props(new DataWebsocketActor(out, children))
}

class DataWebsocketActor(out: ActorRef, children: Seq[ActorRef]) extends Actor {

  var waitingData: Seq[JsValue] = Seq()

  def receive = {
    case StartChildren() =>
      children.foreach(_ ! Start(self))
    case StartDraining() =>
      context.system.scheduler.scheduleOnce(Duration(300, TimeUnit.MILLISECONDS), self, Drain())(context.system.dispatcher)
    case Drain() =>
      if (waitingData.nonEmpty) {
        val data = waitingData.head
        waitingData = waitingData.tail
        out ! data
      }
      context.system.scheduler.scheduleOnce(Duration(300, TimeUnit.MILLISECONDS), self, Drain())(context.system.dispatcher)
    case DataSlug(data) =>
      waitingData = waitingData ++ (data \ "data").as[JsArray].value
      // (data \ "data").as[JsArray].value.foreach(item => out ! item)
    case _ =>
  }

  override def postStop = {
    children.foreach(_ ! Stop())
  }

  override def preStart = {
    self ! StartChildren()
    self ! StartDraining()
  }
}