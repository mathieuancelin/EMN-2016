package services

import java.util.concurrent.TimeUnit

import akka.actor.{Actor, ActorRef, PoisonPill, Props}
import play.api.libs.json.{JsObject, JsValue, Json}
import play.api.libs.ws.WSClient

import scala.concurrent.duration.Duration
import scala.util.{Failure, Success}

case class Start(master: ActorRef)
case class Stop()
case class GetToken()
case class GetData()
case class DataSlug(data: JsValue)

object DataClient {
  def props(id: String, channel: String, ws: WSClient) = Props(new DataClient(id, channel, ws))
}

class DataClient(id: String, channel: String, ws: WSClient) extends Actor {

  implicit val ec = context.system.dispatcher

  var token: JsObject = Json.obj()
  var master: ActorRef = context.system.deadLetters

  def receive = {
    case Start(m) =>
      master = m
      self ! GetToken()
    case GetToken() =>
      println("Fetching a new token ...")
      val me = self
      ws.url(s"https://data-generator-emn.herokuapp.com/token/$id").get().andThen({
        case Failure(e) =>
          println(s"Failure during token fetch ? ${e.getMessage}")
          me ! GetToken()
        case Success(response) => response.status match {
          case 200 =>
            println("New token fetched, now fetching some data ...")
            token = response.json.as[JsObject]
            me ! GetData()
          case 429 =>
            println("Too much request")
            context.system.scheduler.scheduleOnce(Duration(10, TimeUnit.SECONDS)) {
              me ! GetToken()
            }
          case _ => me ! GetToken()
        }

      })
    case GetData() =>
      val me = self
      println("Fetching data ...")
      ws.url(s"https://data-generator-emn.herokuapp.com/data/$channel")
          .withHeaders("X-User-Id" -> id, "X-Auth-Token" -> token.\("value").as[String])
          .get().andThen({
        case Failure(e) =>
          println(s"Failure during data fetch ? ${e.getMessage}")
          me ! GetData()
        case Success(response) => response.status match {
          case 200 =>
            println("Got some fresh data ;-)")
            master ! DataSlug(response.json)
            context.system.scheduler.scheduleOnce(Duration(4, TimeUnit.SECONDS)) {
              me ! GetData()
            }
          case 403 =>
            println("Token is not good anymore")
            me ! GetToken()
          case 429 =>
            println("Too much request")
            context.system.scheduler.scheduleOnce(Duration(4, TimeUnit.SECONDS)) {
              me ! GetData()
            }
          case 490 =>
            println("No X-User-Id header specified")
            me ! GetToken()
          case 491 =>
            println("No X-Auth-Token header specified")
            me ! GetToken()
          case 492 =>
            println("You don't have any Auth Token generated")
            me ! GetToken()
          case 493 =>
            println("Bad X-Auth-Token value")
            me ! GetToken()
          case _ => me ! GetData()
        }
      })
    case Stop() => self ! PoisonPill
    case _ => println("Not handled !!!")
  }
}
