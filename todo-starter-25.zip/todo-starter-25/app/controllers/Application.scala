package controllers

import java.util.UUID
import javax.inject._

import models.Task
import models.Task.taskFormat
import play.api.db.Database
import play.api.libs.json.{Json, Writes}
import play.api.mvc._

@Singleton
class Application @Inject()()(implicit database: Database) extends Controller {

  def index = Action {
    Ok(views.html.index())
  }

  def allTasks() = ???

  def deleteAllDone() = ???

  def changeTaskState(id: String) = Action(parse.urlFormEncoded) { r =>
    val done: Option[String] = r.body.getOrElse("done", Seq()).headOption
    ???
  }

  def createTask() = Action(parse.urlFormEncoded) { r =>
    val name: Option[String] = r.body.getOrElse("name", Seq()).headOption
    ???
  }

  def getTask(id: String) = ???

  def deleteTask(id: String) = ???

  def deleteAll() = ???
}