package models

import java.util.UUID

import anorm.SqlParser._
import anorm._
import play.api.db.Database
import play.api.libs.functional.syntax._
import play.api.libs.json._

case class Task(id: String = UUID.randomUUID().toString, name: String, done: Boolean)

object Task {


  implicit val taskFormat: Format[Task] = ???

  val parser: RowParser[Task] = ???

  def findAll()(implicit db: Database): List[Task] = db.withConnection { implicit connection =>
    SQL("select * from task").as(parser *)
  }

  def findById(id: UUID)(implicit db: Database): Option[Task] = ???

  def create(model: Task)(implicit db: Database): Task = ???

  def delete(model: Task)(implicit db: Database): Unit = ???

  def delete(id: UUID)(implicit db: Database): Unit = ???

  def deleteAll()(implicit db: Database): Unit = ???

  def update(model: Task)(implicit db: Database): Task = ???

  def count()(implicit db: Database): Long = ???

  def exists(model: Task)(implicit db: Database): Boolean = ???

}