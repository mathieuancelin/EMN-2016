package models

import java.util.UUID

import anorm.SqlParser._
import anorm._
import play.api.db.Database
import play.api.libs.functional.syntax._
import play.api.libs.json._

case class Task(id: String = UUID.randomUUID().toString, name: String, done: Boolean)

object Task {

  implicit val taskFormat = Json.format[Task]

  val parser: RowParser[Task] = str("id") ~ str("name") ~ bool("done") map {
    case id ~ name ~ done => Task(id, name, done)
  }

  def findAll()(implicit db: Database): List[Task] = db.withConnection { implicit connection =>
    SQL("select * from task").as(parser *)
  }

  def findById(id: String)(implicit db: Database): Option[Task] = db.withConnection { implicit connection =>
    SQL("select * from task s where s.id = {id}").on("id" -> id).as(parser.singleOpt)
  }

  def create(model: Task)(implicit db: Database): Task = db.withConnection { implicit connection =>
    SQL("insert into task values ({id}, {name}, {done})")
      .on("id" -> model.id, "name" -> model.name, "done" -> model.done).executeUpdate()
    model
  }

  def delete(model: Task)(implicit db: Database): Unit = db.withConnection { implicit connection =>
    SQL("delete from task where id = {id}").on("id" -> model.id).executeUpdate()
  }

  def delete(id: String)(implicit db: Database): Unit = db.withConnection { implicit connection =>
    SQL("delete from task where id = {id}").on("id" -> id).executeUpdate()
  }

  def deleteAll()(implicit db: Database): Unit = db.withConnection { implicit connection =>
    SQL("delete from task").executeUpdate()
  }

  def update(model: Task)(implicit db: Database): Task = db.withConnection { implicit connection =>
    SQL("update task set name = {name}, done = {done} where id = {id}")
      .on("id" -> model.id, "name" -> model.name, "done" -> model.done).executeUpdate()
    model
  }

  def count()(implicit db: Database): Long = db.withConnection { implicit connection =>
    val firstRow = SQL("select count(*) as c from task").apply().head
    firstRow[Long]("c")
  }

  def exists(model: Task)(implicit db: Database): Boolean = findById(model.id).isDefined
}